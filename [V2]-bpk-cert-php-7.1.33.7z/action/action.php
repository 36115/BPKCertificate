<?php
    // เริ่ม Session (ต้องมีทุกหน้า)
    session_start();
    require '../config.php';

    // เช็คว่าส่งมาจาก URL ไหน
    if (isset($_GET["from"])) {
        $from = $_GET["from"];
        parse_url($from, PHP_URL_QUERY);
        parse_str(parse_url($from, PHP_URL_QUERY), $params);
        $id = $params['id'];
        
        if (strpos($_SERVER['REQUEST_URI'], "user-info") !== false) {
            $page = "../user-info?id=$id";
        }
    } else {
        $page = "../";
    }

    // ขอ UserID ผู้ใช้
    $user_id = $_SESSION['user_id'];
    $id = $_GET["id"];

    // ขอ UserID ผู้ใช้
    $user_id = $_SESSION['user_id'];
    $stmt = $pdo -> prepare("SELECT * FROM users WHERE id = ?");
    $stmt -> execute([$user_id]);
    $userData = $stmt -> fetch();

    if ($user_id == $id || $userData['role']  == "admin") {
        $cert_sem = $_POST['cert_sem'];
        $cert_sub = $_POST['cert_sub'];
        $cert_name = $_POST['cert_name'];
        $cert_tname = $_POST['fname']." ".$_POST['lname'];
        $cert_link = "";

        try {

            // บันทึกข้อมูลลงใน Table - cert_list (ของ User นั้นๆ)
            $stmt = $pdo -> prepare("UPDATE cert_list SET cert_sem = ?, cert_sub = ?, cert_name = ?, cert_tname = ?, cert_link = ? WHERE id = ".$id."");
            $stmt -> bindParam(1, $cert_sem, PDO::PARAM_STR);
            $stmt -> bindParam(2, $cert_sub, PDO::PARAM_INT);
            $stmt -> bindParam(3, $cert_name, PDO::PARAM_STR);
            $stmt -> bindParam(4, $cert_tname, PDO::PARAM_STR);
            $stmt -> bindParam(5, $cert_link, PDO::PARAM_STR);
            $stmt -> execute();

            // กลับหน้าหลัก
            $_SESSION['success'] = "บันทึกข้อมูลสำเร็จ!";
            header("location: $page");

        } catch (PDOException $e) {
            $_SESSION['error'] = "มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง";
            $_SESSION['log'] = $e;
            header("location: $page");
        }

    } else {
        $_SESSION['error'] = "กรุณาลองอีกครั้ง";
        header("location: $page");
    }
