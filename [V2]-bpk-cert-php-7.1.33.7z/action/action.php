<?php
    // เริ่ม Session (ต้องมีทุกหน้า)
    session_start();
    require '../config.php';
    
    // เช็คว่าส่งมาจาก URL ไหน
    $page = '../';

    if (isset($_GET["from"])) {
        $from = $_GET["from"];
        parse_url($from, PHP_URL_QUERY);
        parse_str(parse_url($from, PHP_URL_QUERY), $params);
        $id = $params['id'];
        
        if (strpos($_SERVER['REQUEST_URI'], "user-info") !== false) {
            $page = "../user-info?id=$id";
        }
    }

    // เช็ค Action จากลิงก์ที่ส่งมา
    if (isset($_GET["action"])) {
        $action = $_GET["action"];

        // เช็ค Action ว่าเป็นรูปแบบไหน
        if ($action == "certEdit") {
            $table = "cert_list";
        }

    } else {
        $table = "cert_list";
    }

    // ขอ UserID ผู้ใช้
    $id = $_GET["id"];
    $user_id = $_SESSION['user_id'];
    $stmt = $pdo -> prepare("SELECT * FROM users WHERE id = ?");
    $stmt -> execute([$user_id]);
    $userData = $stmt -> fetch();

    if (isset($_GET["action"])) {

        if (isset($_POST['cert_sem'])) {
            $cert_sem = $_POST['cert_sem']; 
        }
        
        if (isset($_POST['cert_sub'])) {
            if (in_array($_POST['cert_sub'], range(1, 8)) || trim($_POST['cert_sub']) == '') {
                $cert_sub = (int) $_POST['cert_sub'];
            } else {
                $_SESSION['error'] = "ไม่สามารถทำรายการได้ในขณะนี้";
                header("location: $page");
                exit;
            }
        }

        if (isset($_POST['cert_name'])) {
            $cert_name = $_POST['cert_name'];
        }

        if (isset($_POST['fname']) && isset($_POST['lname']) && trim($_POST['fname']) !== '' && trim($_POST['lname']) !== '') {
            $cert_tname = trim($_POST['fname']) . " " . trim($_POST['lname']);
        }

        $cert_link = "";

        if (isset($_GET["type"])) {
            $type = $_GET["type"];
        }

        if ($type == "multi") { // หลายรายการ

            if (isset($_POST["idcheckbox"])) {
                $list_arr = $_POST["idcheckbox"];
                $list = implode(",", $list_arr);
            } else {
                $_SESSION['error'] = "ไม่สามารถทำรายการได้ในขณะนี้";
                header("location: $page");
                exit;
            }

            try {
                if ($action == "certEdit") {
                    $updateFields = [];
                    $params = [];

                    if (!empty($cert_sem)) {
                        $updateFields[] = "cert_sem = :cert_sem";
                        $params[':cert_sem'] = $cert_sem;
                    }

                    if (!empty($cert_sub)) {
                        $updateFields[] = "cert_sub = :cert_sub";
                        $params[':cert_sub'] = $cert_sub;
                    }

                    if (!empty($cert_name)) {
                        $updateFields[] = "cert_name = :cert_name";
                        $params[':cert_name'] = $cert_name;
                    }

                    if (!empty($cert_tname)) {
                        $updateFields[] = "cert_tname = :cert_tname";
                        $params[':cert_tname'] = $cert_tname;
                    }

                    if (isset($link)) {
                        $updateFields[] = "cert_link = :cert_link";
                        $params[':cert_link'] = $link;
                    }

                    if (!empty($updateFields)) {
                        $sql = "UPDATE $table SET " . implode(", ", $updateFields) . " WHERE id IN ($list)";
                        $stmt = $pdo -> prepare($sql);
                        $stmt->execute($params);
                    }
                } else {
                    $_SESSION['error'] = "ไม่สามารถทำรายการได้ในขณะนี้";
                    header("location: $page");
                    exit;
                }

                if ($action == "certEdit") {
                    $_SESSION['success'] = "แก้ไขรายการเกียรติบัตรที่เลือกทั้งหมด ".count($list_arr)." รายการแล้ว";
                }

                header("location: $page");
                exit;

            } catch (PDOException $e) {
                if ($action == "certEdit") {
                    $_SESSION['error'] = "ไม่สามารถแก้ไขรายการเกียรติบัตรที่เลือกทั้งหมด ".count($list_arr)." รายการได้ในขณะนี้";
                }

                $_SESSION['log'] = $e;
                header("location: $page");
                exit;
            }
        } else if ($user_id == $id || $userData['role']  == "admin") {
            try {
                // บันทึกข้อมูลลงใน Table - cert_list (ของ User นั้นๆ)
                $stmt = $pdo -> prepare("UPDATE cert_list SET cert_sem = ?, cert_sub = ?, cert_name = ?, cert_tname = ?, cert_link = ? WHERE id = ?");
                $stmt->bindParam(1, $cert_sem, PDO::PARAM_STR);
                $stmt->bindParam(2, $cert_sub, PDO::PARAM_INT);
                $stmt->bindParam(3, $cert_name, PDO::PARAM_STR);
                $stmt->bindParam(4, $cert_tname, PDO::PARAM_STR);
                $stmt->bindParam(5, $cert_link, PDO::PARAM_STR);
                $stmt->bindParam(6, $id, PDO::PARAM_INT);
                $stmt->execute();

                // กลับหน้าหลัก
                $_SESSION['success'] = "บันทึกข้อมูลสำเร็จ!";
                header("location: $page");

            } catch (PDOException $e) {
                $_SESSION['error'] = "มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง";
                $_SESSION['log'] = $e;
                header("location: $page");
            }
        }
    } else {
        $_SESSION['error'] = "กรุณาลองอีกครั้ง";
        header("location: $page");
    }