<?php
    // ค่าสำหรับเข้าหน้าเว็บได้
    define('SECURE_ACCESS', true);

    // เริ่ม Session (ต้องมีทุกหน้า)
    session_start();
    require "../config.php";

    // เช็คว่าส่งมาจาก URL ไหน
    if (isset($_GET["ids"])) {
        $ids = $_GET["ids"];
    }

    if (isset($_GET["from"])) {
        $from = $_GET["from"];
        parse_url($from, PHP_URL_QUERY);
        parse_str(parse_url($from, PHP_URL_QUERY), $params);
        $id = $params['id'];
        
        if (strpos($_SERVER['REQUEST_URI'], "user-info") !== false) {
            $page = "../user-info?id=$id";
        }
    } else {
        $page = "../";
    }
    
    $stmt = $pdo -> prepare("SELECT * FROM cert_list WHERE id = ('$ids')");
    $stmt -> execute();
    $certInfo = $stmt -> fetch();

    // แปลงเวลา
    function convertDate($def) {
        $date = date_create($def);
        $year = (int)$date->format('Y') + 543;
        $index = ['มกราคม', 'กุมภาพันธ์', 'มีนาคม', 'เมษายน', 'พฤษภาคม', 'มิถุนายน', 'กรกฎาคม', 'สิงหาคม', 'กันยายน', 'ตุลาคม', 'พฤศจิกายน', 'ธันวาคม'];
        $monthIndex = (int)$date->format('n') - 1;
        $month = $index[$monthIndex];

        $optDate = $date->format("j {$month} {$year}");
        $optTime = $date->format("H:i:s");
        return [$optDate, $optTime];
    }

    $optCon = convertDate($certInfo['cert_date']);
    list($optDate, $optTime) = $optCon;

    if (isset($certInfo['id'])) {

        $_SESSION["action"] = "editCert";

        $_SESSION["id"] = $certInfo['id'];
        $_SESSION["cert_sem"] = $certInfo['cert_sem'];
        $_SESSION["cert_sub"] = $certInfo['cert_sub'];
        $_SESSION["cert_name"] = $certInfo['cert_name'];
        $_SESSION["cert_type"] = $certInfo['cert_type'];
        $_SESSION["cert_tname"] = $certInfo['cert_tname'];
        $_SESSION["cert_req"] = $certInfo['cert_req'];
        $_SESSION["cert_snum"] = $certInfo['cert_snum'];
        $_SESSION["cert_enum"] = $certInfo['cert_enum'];
        $_SESSION["cert_sym"] = $certInfo['cert_sym'];
        $_SESSION["optDate"] = $optDate;
        $_SESSION["optTime"] = $optTime;

        header("location: $page");
    } else {
        $_SESSION['error'] = "<b>ไม่พบรายการนี้!</b>";
        header("location: $page");
    }