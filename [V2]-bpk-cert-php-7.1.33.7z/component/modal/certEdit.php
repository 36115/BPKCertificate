<?php
    // ป้องกันการเข้าแบบไม่ถูกต้อง
    if (!defined('SECURE_ACCESS')) {
        header("location: ../../action");
    }
?>

<div class="modal fade" id="certEdit" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border border-2 bg-body py-5 rounded-4">
            <div class="modal-header">
                <h1 class="modal-title fs-5 text-body-emphasis fw-bold">แก้ไขข้อมูลหลายรายการ<br><br><small class="text-muted">(ถ้าไม่ต้องการเปลี่ยนช่องนั้นให้เว้นว่างไว้)</small></h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            
            <div class="modal-body">
                <div class="row g-3 align-items-center rounded-3 mb-2">
                    <div class="col-md-6">
                        <label class="form-label text-body-emphasis">ปีการศึกษา</label>
                        <select name="cert_sem" class="form-select text-body-emphasis rounded-pill">
                            <option value="" selected>- ไม่เปลี่ยน -</option>
                            <option value="2/2567">2/2567</option>
                            <option value="1/2568">1/2568</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label class="form-label text-body-emphasis">กลุ่มสาระการเรียนรู้</label>
                        <select name="cert_sub" class="form-select text-body-emphasis rounded-pill">
                            <option value="" selected>- ไม่เปลี่ยน -</option>
                            <option value="1">ภาษาไทย</option>
                            <option value="2">คณิตศาสตร์</option>
                            <option value="3">ภาษาต่างประเทศ</option>
                            <option value="4">วิทยาศาสตร์เเละเทคโนโลยี</option>
                            <option value="5">สังคมศึกษาศาสนาเเละวัฒนธรรม</option>
                            <option value="6">สุขศึกษาเเละพลศึกษา</option>
                            <option value="7">การงานอาชีพ</option>
                            <option value="8">ศิลปะ</option>
                        </select>
                    </div>

                    <div class="col-12">
                        <label for="validName" class="form-label text-body-emphasis">ชื่อกิจกรรม</label>
                        <input type="text" id="validName" name="cert_name" class="form-control text-body-emphasis rounded-pill" placeholder="กรอกชื่อกิจกรรม" autocapitalize="none">
                    </div>

                    <div class="col-12">
                        <label for="validTeacher" class="form-label text-body-emphasis">ชื่อครู</label>
                        <div class="input-group" id="validTeacher">
                            <span class="input-group-text rounded-start-pill" id="name-symbol">ชื่อ</span>
                            <input type="text" name="fname" class="form-control text-body-emphasis" placeholder="ชื่อ" autocapitalize="none" aria-describedby="name-symbol">
                            
                            <span class="input-group-text" id="surname-symbol">นามสกุล</span>
                            <input type="text" name="lname" class="form-control text-body-emphasis rounded-end-pill" placeholder="นามสกุล" autocapitalize="none" aria-describedby="surname-symbol">
                        </div>
                    </div>
                </div>
            </div>
                <div class="m-5 text-center">
                    <button type="submit" name="certEdit" class="btn btn-light border mt-2 rounded-pill" onclick="return confirm('คุณต้องการแก้ไขข้อมูลหรือไม่')">บันทึก</button>
                </div>
            </div>
        </div>
    </div>
</div>