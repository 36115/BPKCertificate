<?php
    // ป้องกันการเข้าแบบไม่ถูกต้อง
    if (!defined('SECURE_ACCESS')) {
        header("location: ../../action");
    }
    
    // ดึงข้อมูลผู้ใช้ที่ส่งมา
    if (isset($_SESSION["id"])) {
        $id = $_SESSION["id"];
        $cert_sem = $_SESSION["cert_sem"];

        switch ($_SESSION["cert_sub"]) {
            case 1:
                $cert_sub = "ภาษาไทย";
                break;
            case 2:
                $cert_sub = "คณิตศาสตร์";
                break;
            case 3:
                $cert_sub = "ภาษาต่างประเทศ";
                break;
            case 4:
                $cert_sub = "วิทยาศาสตร์เเละเทคโนโลยี";
                break;
            case 5:
                $cert_sub = "สังคมศึกษาศาสนาเเละวัฒนธรรม";
                break;
            case 6:
                $cert_sub = "สุขศึกษาเเละพลศึกษา";
                break;
            case 7:
                $cert_sub = "การงานอาชีพ";
                break;
            case 8:
                $cert_sub = "ศิลปะ";
                break;
            default:
                $cert_sub = "ไม่ระบุ";
            }

        $cert_name = $_SESSION["cert_name"];

        switch ($_SESSION["cert_type"]) {
            case 1:
                $cert_type = "ครูและบุคลากร";
                break;
            case 2:
                $cert_type = "นักเรียน";
                break;
            case 3:
                $cert_type = "บุคคลภายนอก";
                break;
            default:
                $cert_type = "ไม่ระบุ";
            }

        if (isset($_SESSION["cert_tname"])) {
            $cert_tname = preg_split('/\s+/', $_SESSION["cert_tname"]);
        }
        
        $cert_req = $_SESSION["cert_req"];
        $cert_snum = $_SESSION["cert_snum"];
        $cert_enum = $_SESSION["cert_enum"];
        $cert_sym = $_SESSION["cert_sym"];
        $optDate = $_SESSION["optDate"];
        $optTime = $_SESSION["optTime"];

        $action = $_SESSION["action"];
    }

    if (isset($_SESSION["id"])) {
        echo "<script type='text/javascript'>
            $(document).ready(function(){
                $('#editCert').modal('show');
            });
        </script>";
    }

    unset($_SESSION['id']);
    unset($_SESSION['cert_sem']);
    unset($_SESSION['cert_sub']);
    unset($_SESSION['cert_name']);
    unset($_SESSION['cert_type']);
    unset($_SESSION['cert_tname']);
    unset($_SESSION['cert_req']);
    unset($_SESSION['cert_snum']);
    unset($_SESSION['cert_enum']);
    unset($_SESSION['cert_date']);
    unset($_SESSION['action']);
?>

<div class="modal fade" id="editCert" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content border border-2 bg-body p-5 pb-lg-0 rounded-4">

            <style>
                fieldset {
                    display: none;
                }

                fieldset.show {
                    display: block;
                }

                .tabs {
                    cursor: pointer;
                }

                .tabs:hover, .tabs.active {
                    border-bottom: 3px solid var(--bs-link-color);
                    border-radius: 3px;
                }
            </style>

            <div class="d-flex justify-content-between">
                <h3 class="text-center fw-bolder p-2"><span class="fas fa-certificate"></span> เกียรติบัตรรายการที่ <?php echo $id;?></h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="nav justify-content-center">
                <div class="tabs mx-4 active" id="certInfoList">
                    <h6 class="fw-bolder"><span class="fas fa-circle-info"></span> ข้อมูลเกียรติบัตร</h6>
                </div>
                
                <div class="tabs mx-4" id="editCert">
                    <h6 class="text-muted"><span class="fas fa-pencil"></span> แก้ไขข้อมูล</h6>
                </div>
            </div>
                
            <div class="modal-body overflow-y-scroll required" style="height: 520px;">

                <fieldset class="show" id="certInfoListPage">
                    <h5 class="pt-3 pb-3 mb-6 border-bottom">
                        <div class="pb-2"><span class="fa fa-circle-info"></span> <?php echo $cert_name;?></div>
                        <div class="badge text-bg-primary user-select-none rounded-pill">กลุ่มสาระการเรียนรู้ <?php echo $cert_sub;?></div>
                    </h5>
                    <div class="mb-2 align-items-center rounded-3">
                        <div class="text-center text-body-emphasis">
                            <img class="img-fluid rounded-3" src="https://fakeimg.pl/110x80?text=Certificate+Image" width="400"/>
                        </div>

                        <div class="card-body p-4">

                            <h6 class="dropdown-toggle user-select-none hover" href="#detail" data-bs-toggle="collapse">รายละเอียด</h6>
                            <hr class="mt-0 mb-4">
                            <div class="collapse row pt-1 show" id="detail">
                                <div class="col-8 col-md-6 mb-3">
                                    <h6>ชื่อกิจกรรม</h6>
                                    <p class="text-muted"><?php echo $cert_name;?></p>
                                </div>
                                <div class="col-6 mb-3">
                                    <h6>กลุ่มสาระการเรียนรู้</h6>
                                    <p class="text-muted"><?php echo $cert_sub;?></p>
                                </div>
                                <div class="col-6 mb-3">
                                    <h6>ประเภทกิจกรรม</h6>
                                    <p class="text-muted"><?php echo $cert_type;?></p>
                                </div>
                                <div class="col-6 mb-3">
                                    <h6>ชื่อครู</h6>
                                    <p class="text-muted"><?php echo $cert_tname[0]." ".$cert_tname[1];?></p>
                                </div>
                                <div class="col-6 mb-3">
                                    <h6>วันที่ขอ</h6>
                                    <p class="text-muted"><?php echo $optDate;?> <br><b>เวลา: <?php echo $optTime?></b></p>
                                </div>
                                <div class="col-8 col-md-6 mb-3">
                                    <h6>จำนวนเกียรติบัตรที่ขอ</h6>
                                    <p class="text-muted"><?php echo $cert_req;?> ใบ<br>
                                        <b><?php echo $cert_sym;?>. <?php echo $cert_snum;?>
                                        <?php if ($cert_snum == $cert_enum) {?>
                                            <?php echo "";?>
                                        <?php } else {?> - <?php echo $cert_enum; }?></b>
                                    </p>
                                </div>
                            </div>

                        </div>

                    </div>
                </fieldset>

                <fieldset id="editCertPage">
                    <h5 class="pt-3 pb-3 mb-6 border-bottom"><span class="fa fa-pencil"></span> แก้ไขข้อมูล</h5>
                    <div class="mb-2 align-items-center rounded-3">
                        <form class="required needs-validation row g-3 mt-3" action="action/action.php?id=<?php echo $id;?>&action=<?php echo $action?>&from=<?php echo $_SERVER['REQUEST_URI'];?>" method="POST" novalidate>

                            <div class="col-md-6">
                                <label class="form-label text-body-emphasis">ปีการศึกษา</label>
                                <select name="cert_sem" class="form-select text-body-emphasis rounded-pill" required>
                                    <option value="2/2567" <?php if ($cert_sem == "2/2567") echo "selected";?>>2/2567</option>
                                    <option value="1/2568" <?php if ($cert_sem == "1/2567") echo "selected";?>>1/2568</option>
                                </select>
                                <div class="invalid-feedback">กรุณาเลือกปีการศึกษา</div>
                            </div>

                            <div class="col-md-6">
                                <label class="form-label text-body-emphasis">กลุ่มสาระการเรียนรู้</label>
                                <select name="cert_sub" class="form-select text-body-emphasis rounded-pill" required>
                                    <option value="1" <?php if ($cert_sub == "1") echo "selected";?>>ภาษาไทย</option>
                                    <option value="2" <?php if ($cert_sub == "2") echo "selected";?>>คณิตศาสตร์</option>
                                    <option value="3" <?php if ($cert_sub == "3") echo "selected";?>>ภาษาต่างประเทศ</option>
                                    <option value="4" <?php if ($cert_sub == "4") echo "selected";?>>วิทยาศาสตร์เเละเทคโนโลยี</option>
                                    <option value="5" <?php if ($cert_sub == "5") echo "selected";?>>สังคมศึกษาศาสนาเเละวัฒนธรรม</option>
                                    <option value="6" <?php if ($cert_sub == "6") echo "selected";?>>สุขศึกษาเเละพลศึกษา</option>
                                    <option value="7" <?php if ($cert_sub == "7") echo "selected";?>>การงานอาชีพ</option>
                                    <option value="8" <?php if ($cert_sub == "8") echo "selected";?>>ศิลปะ</option>
                                </select>
                                <div class="invalid-feedback">กรุณาเลือกกลุ่มสาระ</div> 
                            </div>

                            <div class="col-12">
                                <label for="validName" oninput="checkInput()" class="form-label text-body-emphasis">ชื่อกิจกรรม</label>
                                <input type="text" id="validName" name="cert_name" class="form-control text-body-emphasis rounded-pill" value="<?php echo $cert_name;?>" placeholder="กรอกชื่อกิจกรรม" autocapitalize="none" required>
                                <div class="invalid-feedback">กรุณากรอกชื่อกิจกรรม</div>
                            </div>

                            <div class="col-12">
                                <label for="validTeacher" oninput="checkInput()" class="form-label text-body-emphasis">ชื่อครู</label>
                                <div class="input-group" id="validTeacher">
                                    <span class="input-group-text rounded-start-pill" id="name-symbol">ชื่อ</span>
                                    <input type="text" name="fname" class="form-control text-body-emphasis" value="<?php echo $cert_tname[0];?>" placeholder="ชื่อ" autocapitalize="none" aria-describedby="name-symbol" required>
                                    
                                    <span class="input-group-text" id="surname-symbol">นามสกุล</span>
                                    <input type="text" name="lname" class="form-control text-body-emphasis rounded-end-pill" value="<?php echo $cert_tname[1];?>" placeholder="นามสกุล" autocapitalize="none" aria-describedby="surname-symbol" required>
                                    <div class="invalid-feedback">กรุณากรอกชื่อ-นามสกุลครู</div>
                                </div>
                            </div>

                            <div class="text-center">
                                <button type="submit" name="editCert" class="btn btn-light border mt-2 rounded-pill" onclick="return confirm('คุณต้องการบันทึกข้อมูลหรือไม่')">บันทึก</button>
                            </div>

                        </form>
                    </div>
                </fieldset>
            </div>
        </div>
    </div>
</div>