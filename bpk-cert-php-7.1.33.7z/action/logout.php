<?php
    // ป้องกันการเข้าแบบไม่ถูกต้อง
    if (!defined('SECURE_ACCESS')) {
        header("location: ../action");
    }

    session_start();
    session_destroy();
    header("location: ../login");
