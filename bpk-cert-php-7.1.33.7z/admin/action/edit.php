<?php
    // ค่าสำหรับเข้าหน้าเว็บได้
    define('SECURE_ACCESS', true);

    // เริ่ม Session (ต้องมีทุกหน้า)
    session_start();
    require "../../config.php";

    // ขอ UserID ผู้ใช้
    $user_id = $_SESSION['user_id'];
    $stmt = $pdo -> prepare("SELECT * FROM users WHERE id = ?");
    $stmt -> execute([$user_id]);
    $userData = $stmt -> fetch();

    if ($userData['role']  !== "admin") {
        header("location: ../../action");
    } else {
        if (isset($_GET["reqid"])) {
            $req_id = $_GET["reqid"];
            $_SESSION["reqid"] = $req_id;
        }

        // เช็คว่าส่งมาจาก URL ไหน
        if (isset($_GET["id"])) {
            $id = $_GET["id"];
        }

        if (isset($_GET["from"])) {
            if (strpos($_SERVER['REQUEST_URI'], "user-info") !== false) {
                $page = "../../user-info?id=$id";
            } else if (strpos($_SERVER['REQUEST_URI'], "userRequest") !== false) {
                $page = "../../dashboard";
            }
        } else {
            $page = "../../dashboard";
        }

        require_once '../page/userEditModal.php';
    }