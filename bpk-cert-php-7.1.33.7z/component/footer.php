<?php
    // ป้องกันการเข้าแบบไม่ถูกต้อง
    if (!defined('SECURE_ACCESS')) {
        header("location: ./action");
    }
    
    include_once  __DIR__ . '/modal/requestUser.php';
    
    if ($userData['role']  == "admin") {
        include_once  __DIR__ . '/modal/adminMenu.php';
    } elseif ($userData['role']  !== "admin") {
        include_once  __DIR__ . '/modal/about.php';
    }
?>

<style>
    .mapouter {
        text-align: right;
        height: 300px;
        width: 100%;
    }
    .gmap_canvas {
        overflow: hidden;
        background: none !important;
        height: 300px;
        width: 100%;
    }
</style>

<body class="d-flex flex-column min-vh-100">
        <div class="wrapper flex-grow-1"></div>

        <footer class="pt-5 border text-md-left">
            <div class="container p-4">
                <div class="row">
                    <div class="col-md-3 pb-4">
                        <a class="navbar-brand" href="/<?php echo $rootname; ?>">
                            <img src="https://www.bpk.ac.th/bpknews/assets/images/img/BPK_Logo.png" width="35" height="40">
                            <span class="fw-bold fs-5">โรงเรียนบางปะกอกวิทยาคม</span>
                        </a>

                        <div class="pt-4 pb-0">
                            <p><i class="fa fa-address-card"></i> 51 ซอยสุขสวัสดิ์ 19 ถนนสุขสวัสดิ์ <br>เเขวงบางปะกอก เขตราษฎ์บูรณะ กรุงเทพมหานครเขต 10140</p>
                        </div>

                        <div class="pb-4">
                            <i class="fa fa-envelope"></i>
                            <a href="mailto:bangpakok@bpk.ac.th">bangpakok@bpk.ac.th</a>
                        </div>

                        <div class="pb-0">
                            <i class="fa fa-phone-square"> ประชาสัมพันธ์</i>
                            <p class="pt-2"><a href="tel:0242889804">024-288-9804</a></p>
                        </div>

                        <div class="pb-0">
                            <i class="fa fa-phone-square"> กลุ่มบริหารงานทั่วไป</i>
                            <p class="pt-2"><a href="tel:0982801073">098-280-1073</a></p>
                        </div>

                        <div class="pb-0">
                            <i class="fa fa-phone-square"> กลุ่มบริหารงานบุคคล</i>
                            <p class="pt-2"><a href="tel:0631959039">063-195-9039</a></p>
                        </div>

                        <div class="pb-0">
                            <i class="fa fa-phone-square"> กลุ่มบริหารงบประมาณ</i>
                            <p class="pt-2"><a href="tel:0982801071">098-280-1071</a></p>
                        </div>

                        <div class="pb-0">
                            <i class="fa fa-phone-square"> กลุ่มบริหารวิชาการ</i>
                            <p class="pt-2 pb-0"><a href="tel:024278942">024-278-942</a> / <a href="tel:0982801072">098-280-1072</a></p>
                        </div>
                        
                    </div>

                    <div class="col-md-3 pb-4">
                        <h4><i class="fas fa-graduation-cap"></i> กลุ่มสาระการเรียนรู้</h4>

                        <ul class="navbar-nav">
                            <li class="nav-item pt-1 pb-1">
                                <a class="nav-link" href="https://www.bpk.ac.th/Techer_directory/thai.php" target="_blank"> <i class="fa fa-book"></i> กลุ่มสาระการเรียนรู้ภาษาไทย</a>
                            </li>

                            <li class="nav-item pb-1">
                                <a class="nav-link" href="https://www.bpk.ac.th/Techer_directory/mathematics.php" target="_blank"> <i class="fa fa-book"></i> กลุ่มสาระการเรียนรู้คณิตศาสตร์</a>
                            </li>

                            <li class="nav-item pb-1">
                                <a class="nav-link" href="https://www.bpk.ac.th/Techer_directory/foreign.php" target="_blank"> <i class="fa fa-book"></i> กลุ่มสาระการเรียนรู้ภาษาต่างประเทศ</a>
                            </li>

                            <li class="nav-item pb-1">
                                <a class="nav-link" href="https://www.bpk.ac.th/Techer_directory/science.php" target="_blank"> <i class="fa fa-book"></i> กลุ่มสาระการเรียนรู้วิทยาศาสตร์เเละเทคโนโลยี</a>
                            </li>

                            <li class="nav-item pb-1">
                                <a class="nav-link" href="https://www.bpk.ac.th/Techer_directory/social.php" target="_blank"> <i class="fa fa-book"></i> กลุ่มสาระการเรียนรู้สังคมศึกษาศาสนาเเละวัฒนธรรม</a>
                            </li>

                            <li class="nav-item pb-1">
                                <a class="nav-link" href="https://www.bpk.ac.th/Techer_directory/physical.php" target="_blank"> <i class="fa fa-book"></i> กลุ่มสาระการเรียนรู้สุขศึกษาเเละพลศึกษา</a>
                            </li>

                            <li class="nav-item pb-1">
                                <a class="nav-link" href="https://www.bpk.ac.th/Techer_directory/career.php" target="_blank"> <i class="fa fa-book"></i> กลุ่มสาระการเรียนรู้การงานอาชีพ</a>
                            </li>

                            <li class="nav-item pb-1">
                                <a class="nav-link" href="https://www.bpk.ac.th/Techer_directory/art.php" target="_blank"> <i class="fa fa-book"></i> กลุ่มสาระการเรียนรู้ศิลปะ</a>
                            </li>

                            <li class="nav-item pb-1">
                                <a class="nav-link" href="https://www.bpk.ac.th/Techer_directory/guidance.php" target="_blank"> <i class="fa fa-book"></i> เเนะเเนว</a>
                            </li>
                        </ul>

                    </div>

                    <div class="col-md-3 pb-4">
                        <h4><i class="fas fa-briefcase"></i> หน่วยงานที่เกี่ยวข้อง</h4>

                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <li class="nav-item">
                                    <a class="nav-link" href="https://drive.google.com/drive/folders/1xyz0WXkaL3TgvPYi54WkH41BnmKWbwJv" target="_blank"> <i class="fa fa-user"></i> ชุมชนแห่งการเรียนรู้ PLC</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="https://www.bpk.ac.th/bpknews/Hr_academic.php" target="_blank"> <i class="fa fa-user"></i> งานพัฒนาบุคลากรด้านวิชาการ</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="https://www.bpk.ac.th/bpknews/academic_view.php" target="_blank"> <i class="fa fa-user"></i> การเผยแพร่ผลงานด้านวิชาการ</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="https://sites.google.com/bpk.ac.th/bpk-online-2564/home" target="_blank"> <i class="fa fa-book"></i> ห้องเรียนออนไลน์ BPK Online</a>
                                </li>
                                
                                <li class="nav-item">
                                    <a class="nav-link" href="http://bpk.vlcloud4.net" target="_blank"> <i class="fa fa-search"></i> สืบค้นห้องสมุด</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="https://www.bpk.ac.th/bpknews/Analyze_individual.php" target="_blank"> <i class="fa fa-search"></i> วิเคราะห์ผู้เรียนรายบุคคล</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="https://drive.google.com/drive/folders/1QnSy_gDZ-XajzSeNZQ2AKGP2cJhVTEDV?usp=sharing" target="_blank"> <i class="fa fa-search"></i> รายงานประเมินตนเอง (SAR)</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="https://www.bpk.ac.th/bpknews/Evaluate.php" target="_blank"> <i class="fa fa-search"></i> งานประเมินโครงการโรงเรียนบางปะกอกวิทยาคม</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="https://drive.google.com/file/d/1wpBBUDcTgbJP3Vtfe7oSj9p1_0DgN9eu/view" target="_blank"> <i class="fa fa-users"></i> คู่มือแนวทางการจัดการเรียนรู้รายวิชาเพิ่มเติมหน้าที่พลเมือง</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link" href="https://sites.google.com/bpk.ac.th/classroomresearch/%E0%B8%AB%E0%B8%99%E0%B8%B2%E0%B9%81%E0%B8%A3%E0%B8%81" target="_blank"> <i class="fa fa-users"></i> งานวิจัยเพื่อพัฒนาคุณภาพการศึกษา (วิจัยในชั้นเรียน)</a>
                                </li>

                            </li>
                        </ul>

                    </div>
                
                    <div class="col-md-3 pb-4">
                        <h4>แผนที่</h4>

                        <div class="mapouter">
                            <div class="gmap_canvas">
                                <iframe width="100%" height="300" id="gmap_canvas" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3876.583637898244!2d100.49287431482975!3d13.683063090391956!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x30e2a25f9ccd00fd%3A0x683940d88dab7aee!2z4LmC4Lij4LiH4LmA4Lij4Li14Lii4LiZ4Lia4Liy4LiH4Lib4Liw4LiB4Lit4LiB4Lin4Li04LiX4Lii4Liy4LiE4Lih!5e0!3m2!1sth!2sth!4v1672046761998!5m2!1sth!2sth" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe>
                            </div>
                        </div>

                    </div>

                </div>
            </div>

        </footer>
            <footer class="text-center border px-5 py-5">
                <p class="mt-3 text-body-emphasis">© <?php echo date("Y"); ?> <a class="text-body-emphasis link-underline-none" href="https://www.facebook.com/srvt.sitti" target="_blank">Soravich Sittiborwornsakul.</a></p>
            </footer>
    </body>
</body>