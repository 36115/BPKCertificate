<?php
    // ป้องกันการเข้าแบบไม่ถูกต้อง
    if (!defined('SECURE_ACCESS')) {
        header("location: ../../action");
    }
?>

    <div class="modal fade" id="about" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" style="max-width: 700px;">
            <div class="modal-content border border-2 bg-body p-4 rounded-4">
                <div class="d-flex justify-content-between">
                    <h3 class="text-center fw-bolder p-2"><span class="fas fa-address-card"></span> เกี่ยวกับ</h3>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body overflow-y-scroll">
                    <h5 class="pb-3 mb-6 border-bottom"><span class="fa fa-circle-question"></span> จัดทำโดย</h5>
                    <ul class="mt-3">
                        <li>นายสรวิชญ์ สิทธิบวรสกุล</li>
                    </ul>
                    <h5 class="pt-5 pb-3 mb-6 border-bottom"><span class="fa fa-comments"></span> ทดสอบระบบ / ให้คำแนะนำโดย</h5>
                    <ul class="mt-3">
                        <li>ครูพลากร ศิลาโคตร</li>
                        <li>ครูพิราวรรณ คำสุ</li>
                    </ul>
                </div>

            </div>
        </div>
    </div>