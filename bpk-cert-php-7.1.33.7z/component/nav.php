<?php
    // ป้องกันการเข้าแบบไม่ถูกต้อง
    if (!defined('SECURE_ACCESS')) {
        header("location: ../action");
    }

    $useragent = $_SERVER['HTTP_USER_AGENT'];

    if (preg_match('/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i',substr($useragent,0,4))) {
        $device = "mobile-screen-button";
    } else {
        $device = "desktop";
    }

    // Theme หน้าเว็บเริ่มต้น
    $mode = "auto";
    $webName = "โปรแกรมขอเกียรติบัตร";

    // ขอ UserID ผู้ใช้
    $user_id = $_SESSION['user_id'];
    $stmt = $pdo -> prepare("SELECT * FROM users WHERE id = ?");
    $stmt -> execute([$user_id]);
    $userData = $stmt -> fetch();

    // ดึงค่ารูปแบบ Navbar
    $fetch = $pdo -> prepare('SELECT * FROM settings');
    $fetch -> execute();
    $settings = $fetch -> fetch();
?>

    <!-- Info -->
    <meta name="description" content="เว็บดาวน์โหลดเกียรติบัตรสำหรับการแข่งขัน">
    <meta name="author" content="นายสรวิชญ์ สิทธิบวรสกุล">

    <!-- Favicons -->
    <link rel="icon" type="image/x-icon" href="https://www.bpk.ac.th/bpknews/assets/BPK-LOGO-1.ico">
    <link rel="shortcut icon" type="image/x-icon" href="https://www.bpk.ac.th/bpknews/assets/BPK-LOGO-1.ico"/>

    <!-- Fast Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/fastbootstrap@2.2.0/dist/css/fastbootstrap.min.css" rel="stylesheet" integrity="sha256-V6lu+OdYNKTKTsVFBuQsyIlDiRWiOmtC8VQ8Lzdm2i4=" crossorigin="anonymous">

    <!-- Font Support -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=K2D:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800&display=swap" rel="stylesheet">

    <!-- Font Awesome Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />

<header>

<style>
    * {
    font-family: "K2D", sans-serif;
    font-weight: 400;
    font-style: normal;
    }

    .form-control:valid, .form-control.is-valid, .was-validated, .form-select.is-valid:not([multiple]):not([size]), .form-select.is-valid:not([multiple])[size="1"], .was-validated .form-select:valid:not([multiple]):not([size]), .was-validated .form-select:valid:not([multiple])[size="1"] {
        --bs-form-select-bg-icon: url() !important;
        background-image: url() !important;
        border-color: var(--bs-border-color) !important;
    }

    .bpk-tbheader {
        position: sticky;
        top: -0.1;
    }

    .table-responsive {
        max-height:300px;
    }

    .hover:hover {
        cursor: pointer;
    }

    .table>:not(caption)>*>* {
        background-color: rgba(var(--bs-body-bg-rgb),var(--bs-bg-opacity)) !important;
    }

    div.dt-scroll div.dtfc-top-blocker, div.dt-scroll div.dtfc-bottom-blocker, div.dtfh-floatingparent div.dtfc-top-blocker, div.dtfh-floatingparent div.dtfc-bottom-blocker {
        background-color: transparent !important;
    }

    .required .form-label:after {
        content: " *";
        color: red;
    }

    .options {
        width: 100% !important;
        left: -100px !important;
    }

    @media (min-width: 992px) {
        .options {
            width: 300px !important;
        }
    }
</style>

    <?php if ($settings['navbar_mode'] == 1) { ?>

        <nav class="navbar navbar-expand-lg fixed-top py-5">
            <div class="container">
                <a class="navbar-brand user-select-none" href="/<?php echo $rootname; ?>">
                    <img src="https://www.bpk.ac.th/bpknews/assets/images/img/logobaner.png" width="300" height="70" class="d-inline-block align-top">
                </a>

                <button class="navbar-toggler rounded-3 my-2 collapsed" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
                    <i class="fas fa-bars"></i></span>
                </button>

                <div class="offcanvas offcanvas-end bg-body" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
                    <div class="offcanvas-header py-3">
                        <a class="navbar-brand user-select-none" href="/<?php echo $rootname; ?>">
                            <img src="https://www.bpk.ac.th/bpknews/assets/images/img/logobaner.png" width="250" class="d-inline-block align-top">
                        </a>

                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    
                    <div class="offcanvas-body py-0">
                        <ul class="nav navbar-nav">
                            <li class="nav-item my-2">
                                <a class="text-body-emphasis user-select-none text-decoration-underline" href="https://www.bpk.ac.th/bpknews">หน้าเว็บหลัก</a>
                            </li>
                        </ul>

                        <ul class="nav navbar-nav ms-auto">
                            <li class="nav-item my-2">
                                <div class="dropdown-center">
                                    <button class="btn border text-body-emphasis d-flex dropdown-toggle align-items-center rounded-pill" type="button" id="bd-theme" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fa-solid fa-circle-half-stroke me-2"></i>
                                        <span id="bd-theme-text">โหมด</span>
                                    </button>
                                    <div class="dropdown-menu theme border my-2 dropdown-menu-end rounded-4">
                                        <div>
                                            <button type="button" class="dropdown-item d-flex align-items-center rounded-pill" data-bs-theme-value="light">
                                            <i class="fa-solid fa-sun me-2 theme-icon"></i>
                                            สว่าง
                                            </button>
                                        </div>
                                        <div>
                                            <button type="button" class="dropdown-item d-flex align-items-center rounded-pill" data-bs-theme-value="dark">
                                            <i class="fa-solid fa-moon me-2 theme-icon"></i>
                                            มืด
                                            </button>
                                        </div>
                                        <div>
                                            <button type="button" class="dropdown-item d-flex align-items-center active rounded-pill" data-bs-theme-value="auto">
                                            <i class="fa-solid fa-<?php echo $device;?> me-2 theme-icon"></i>
                                            อุปกรณ์
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="nav-item">
                                <?php if (!isset($_SESSION['user_id'])) { ?>
                                    <a href="login" class="btn btn-light bg-transparent text-body-emphasis border me-2 rounded-pill">เข้าสู่ระบบ</a>
                                    <a href="register" class="btn btn-light rounded-pill" data-bs-toggle="modal" data-bs-target="#regAdmin">ลงทะเบียน</a>
                                    <?php } else { ?>
                                        <div class="dropdown-center">
                                            <button class="btn btn-primary text-white dropdown-toggle rounded-pill" type="button" id="userDropdown" data-bs-toggle="dropdown">
                                                <i class="fa-regular fa-face-smile-wink"></i> สวัสดี, <?php echo $userData['username']; ?>!
                                            </button>
                                            <div class="dropdown-menu options p-3 my-2 border rounded-4">
                                                <div class="p-3 px-1 py-1 mx-2">
                                                    <div class="d-flex align-items-center">
                                                        <img class="d-flex align-items-center rounded-circle border border-1 border-secondary me-2" style="height: 2rem; width: 2rem; background-color: var(--bs-border-color); object-fit: cover;" src="assets/profile/default.jpg">
                                                        <div class="d-inline-flex flex-column">
                                                            <span class="fw-bold"><?php echo $userData['realname']; ?></span>
                                                            <small class="text-muted"><span>@</span><?php echo $userData['username']; ?></small>
                                                            <a id="edit-profile" class="hover" data-bs-toggle="modal" data-bs-target="#editUser">
                                                                แก้ไขข้อมูล <i class="fas fa-edit"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="dropdown-divider"></div>
                                                <h6 class="dropdown-header">เมนู</h6>
                                                <a class="btn btn-info dropdown-item rounded-pill" href="/<?php echo $rootname; ?>">
                                                    หน้าหลัก <i class="fas fa-home float-end"></i>
                                                </a>
                                                <a class="btn btn-info dropdown-item rounded-pill" href="manual">
                                                    คู่มือการใช้งาน <i class="fas fa-book float-end"></i>
                                                </a>
                                                <a class="btn btn-info dropdown-item rounded-pill" data-bs-toggle="modal" data-bs-target="#requestUser">
                                                    แจ้งปัญหาการใช้งาน <i class="fas fa-comment-dots float-end"></i>
                                                </a>
                                                <?php if ($userData['role'] !== "admin") { ?>
                                                    <a class="btn btn-primary dropdown-item rounded-pill" data-bs-toggle="modal" data-bs-target="#about">
                                                        เกี่ยวกับ <i class="fas fa-address-card float-end"></i>
                                                    </a>
                                                <?php }?>
                                                <div class="dropdown-divider"></div>
                                                <a class="btn btn-danger dropdown-item rounded-pill" href="action/logout" onclick="return confirm('คุณต้องการออกจากระบบหรือไม่?')">
                                                    ออกจากระบบ <i class="fas fa-sign-out-alt float-end"></i>
                                                </a>
                                            <?php if ($userData['role'] == "admin") { ?>
                                                <div class="dropdown-divider"></div>
                                                    <h6 class="dropdown-header">สำหรับ Admin</h6>
                                                    <a class="btn btn-primary dropdown-item rounded-pill" data-bs-toggle="modal" data-bs-target="#adminMenu">
                                                        เมนู Admin <i class="fas fa-wrench float-end"></i>
                                                    </a>
                                                </div>
                                            <?php }?>
                                        </div>
                                <?php } ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <?php } else { ?>
            <nav class="navbar navbar-expand-lg fixed-top py-5">
                <div class="container">
                    <a class="navbar-brand user-select-none" href="/<?php echo $rootname; ?>"><img src="https://www.bpk.ac.th/bpknews/assets/images/img/logobaner.png" width="300" height="70" class="d-inline-block align-top"></a>
                    <button class="navbar-toggler rounded-3 my-2 collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavId" aria-controls="collapsibleNavId">
                        <i class="fas fa-bars"></i></span>
                    </button>
                    <div class="collapse navbar-collapse" id="collapsibleNavId">
                        <ul class="nav navbar-nav">
                            <li class="nav-item my-2">
                                <a class="text-body-emphasis user-select-none text-decoration-underline" href="https://www.bpk.ac.th/bpknews">ไปหน้าเว็บหลัก</a>
                            </li>
                        </ul>

                        <ul class="nav navbar-nav ms-auto">
                            <li class="nav-item my-2">
                                <div class="dropdown-center">
                                    <button class="btn border text-body-emphasis d-flex dropdown-toggle align-items-center rounded-pill" type="button" id="bd-theme" data-bs-toggle="dropdown" aria-expanded="false">
                                        <i class="fa-solid fa-circle-half-stroke me-2"></i>
                                        <span id="bd-theme-text">โหมด</span>
                                    </button>
                                    <div class="dropdown-menu theme border my-2 dropdown-menu-end rounded-4">
                                        <div>
                                            <button type="button" class="dropdown-item d-flex align-items-center rounded-pill" data-bs-theme-value="light">
                                            <i class="fa-solid fa-sun me-2 theme-icon"></i>
                                            สว่าง
                                            </button>
                                        </div>
                                        <div>
                                            <button type="button" class="dropdown-item d-flex align-items-center rounded-pill" data-bs-theme-value="dark">
                                            <i class="fa-solid fa-moon me-2 theme-icon"></i>
                                            มืด
                                            </button>
                                        </div>
                                        <div>
                                            <button type="button" class="dropdown-item d-flex align-items-center active rounded-pill" data-bs-theme-value="auto">
                                            <i class="fa-solid fa-<?php echo $device;?> me-2 theme-icon"></i>
                                            อุปกรณ์
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </li>

                            <li class="nav-item">
                                <?php if (!isset($_SESSION['user_id'])) { ?>
                                    <a href="login" class="btn btn-light bg-transparent text-body-emphasis border me-2 rounded-pill">เข้าสู่ระบบ</a>
                                    <a href="register" class="btn btn-light rounded-pill" data-bs-toggle="modal" data-bs-target="#regAdmin">ลงทะเบียน</a>
                                    <?php } else { ?>
                                        <div class="dropdown-center">
                                            <button class="btn btn-primary text-white dropdown-toggle rounded-pill" type="button" id="userDropdown" data-bs-toggle="dropdown">
                                                <i class="fa-regular fa-face-smile-wink"></i> สวัสดี, <?php echo $userData['username']; ?>!
                                            </button>
                                            <div class="dropdown-menu options p-3 my-2 border rounded-4">
                                                <div class="p-3 px-1 py-1 mx-2">
                                                    <div class="d-flex align-items-center">
                                                        <img class="d-flex align-items-center rounded-circle border border-1 border-secondary me-2" style="height: 2rem; width: 2rem; background-color: var(--bs-border-color); object-fit: cover;" src="assets/profile/default.jpg">
                                                        <div class="d-inline-flex flex-column">
                                                            <span class="fw-bold"><?php echo $userData['realname']; ?></span>
                                                            <small class="text-muted"><span>@</span><?php echo $userData['username']; ?></small>
                                                            <a id="edit-profile" class="hover" data-bs-toggle="modal" data-bs-target="#editUser">
                                                                แก้ไขข้อมูล <i class="fas fa-edit"></i>
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="dropdown-divider"></div>
                                                <h6 class="dropdown-header">เมนู</h6>
                                                <a class="btn btn-info dropdown-item rounded-pill" href="/<?php echo $rootname; ?>">
                                                    หน้าหลัก <i class="fas fa-home float-end"></i>
                                                </a>
                                                <a class="btn btn-info dropdown-item rounded-pill" href="manual">
                                                    คู่มือการใช้งาน <i class="fas fa-book float-end"></i>
                                                </a>
                                                <a class="btn btn-info dropdown-item rounded-pill" data-bs-toggle="modal" data-bs-target="#requestUser">
                                                    แจ้งปัญหาการใช้งาน <i class="fas fa-comment-dots float-end"></i>
                                                </a>
                                                <div class="dropdown-divider"></div>
                                                <a class="btn btn-danger dropdown-item rounded-pill" href="action/logout" onclick="return confirm('คุณต้องการออกจากระบบหรือไม่?')">
                                                    ออกจากระบบ <i class="fas fa-sign-out-alt float-end"></i>
                                                </a>
                                            <?php if ($userData['role'] == "admin") { ?>
                                                <div class="dropdown-divider"></div>
                                                    <h6 class="dropdown-header">สำหรับ Admin</h6>
                                                    <a class="btn btn-primary dropdown-item rounded-pill" data-bs-toggle="modal" data-bs-target="#adminMenu">
                                                        เมนู Admin <i class="fas fa-wrench float-end"></i>
                                                    </a>
                                                </div>
                                            <?php }?>
                                        </div>
                                <?php } ?>
                            </li>
                        </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </nav>
        <?php } ?>
</header>

<script>
    (() => {
        'use strict'
        const storedTheme = localStorage.getItem('theme')
        const getPreferredTheme = () => {
            if (storedTheme) {
            return storedTheme
            }
            return 'auto'  // Changed this line to return 'auto' by default
        }
        const setTheme = function (theme) {
            if (theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            document.documentElement.setAttribute('data-bs-theme', 'dark')
            } else if (theme === 'auto') {
            document.documentElement.setAttribute('data-bs-theme', 'light')
            } else {
            document.documentElement.setAttribute('data-bs-theme', theme)
            }
        }
        setTheme(getPreferredTheme())
        const showActiveTheme = theme => {
            const activeThemeIcon = document.querySelector('.theme-icon-active')
            const btnToActive = document.querySelector(`[data-bs-theme-value="${theme}"]`)
            const svgOfActiveBtn = btnToActive.querySelector('i').getAttribute('class')
            document.querySelectorAll('[data-bs-theme-value]').forEach(element => {
            element.classList.remove('active')
            })
            btnToActive.classList.add('active')
            const themeSwitcher = document.querySelector('#bd-theme')
            if (themeSwitcher) {
            const themeSwitcherText = document.querySelector('#bd-theme-text')
            const activeThemeIcon = themeSwitcher.querySelector('i')
            const btnIcon = btnToActive.querySelector('i').getAttribute('class')
            const themeSwitcherLabel = `${btnToActive.textContent} (${theme})`
            activeThemeIcon.setAttribute('class', btnIcon)
            themeSwitcherText.textContent = btnToActive.textContent
            }
        }
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => {
            if (storedTheme !== 'light' && storedTheme !== 'dark') {  // Changed condition to use AND instead of OR
            setTheme(getPreferredTheme())
            }
        })
        window.addEventListener('DOMContentLoaded', () => {
            showActiveTheme(getPreferredTheme())
            document.querySelectorAll('[data-bs-theme-value]')
            .forEach(toggle => {
                toggle.addEventListener('click', () => {
                const theme = toggle.getAttribute('data-bs-theme-value')
                localStorage.setItem('theme', theme)
                setTheme(theme)
                showActiveTheme(theme)
                })
            })
        })
    })()
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>