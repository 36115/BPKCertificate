<?php
    // เริ่ม Session (ต้องมีทุกหน้า)
    session_start();
    require '../config.php';
    
    // เช็คว่าส่งมาจาก URL ไหน
    $page = '../';

    if (isset($_GET["from"])) {
        $from = $_GET["from"];
        parse_url($from, PHP_URL_QUERY);
        parse_str(parse_url($from, PHP_URL_QUERY), $params);
        $id = $params['id'];
        
        if (strpos($_SERVER['REQUEST_URI'], "user-info") !== false) {
            $page = "../user-info?id=$id";
        }
    }

    // เช็ค Action จากลิงก์ที่ส่งมา
    if (isset($_GET["action"])) {
        $action = $_GET["action"];

        // เช็ค Action ว่าเป็นรูปแบบไหน
        if ($action == "certEdit") {
            $table = "cert_list";
        } else {
            $table = "cert_list";
        }

    }

    // ขอ UserID ผู้ใช้
    $id = $_GET["id"];
    $user_id = $_SESSION['user_id'];
    $stmt = $pdo -> prepare("SELECT * FROM users WHERE id = ?");
    $stmt -> execute([$user_id]);
    $userData = $stmt -> fetch();

    if (isset($_GET["action"])) {

        if (isset($_POST['cert_sem'])) {
            $cert_sem = $_POST['cert_sem']; 
        }
        
        if (isset($_POST['cert_sub'])) {
            if (in_array($_POST['cert_sub'], range(1, 8)) || trim($_POST['cert_sub']) == '') {
                $cert_sub = (int) $_POST['cert_sub'];
            } else {
                $_SESSION['error'] = "ไม่สามารถทำรายการได้ในขณะนี้";
                header("location: $page");
                exit;
            }
        }

        if (isset($_POST['cert_name'])) {
            $cert_name = $_POST['cert_name'];
        }

        if (isset($_POST['fname']) && isset($_POST['lname']) && trim($_POST['fname']) !== '' && trim($_POST['lname']) !== '') {
            $cert_tname = trim($_POST['fname']) . " " . trim($_POST['lname']);
        }

        if (isset($_POST['cert_image'])) {
            $cert_image = $_POST['cert_image'];
        }

        if (isset($_POST['cert_num'])) {
            $cert_num = $_POST['cert_num'];
        }

        if (isset($_POST['certExt'])) {
            $certExt = $_POST['certExt'];
        }

        if (isset($_GET["type"])) {
            $type = $_GET["type"];
        }

        $updateFields = [];
        $params = [];

        if (!empty($cert_sem)) {
            $updateFields[] = "cert_sem = :cert_sem";
            $params[':cert_sem'] = $cert_sem;
        }

        if (!empty($cert_sub)) {
            $updateFields[] = "cert_sub = :cert_sub";
            $params[':cert_sub'] = $cert_sub;
        }

        if (!empty($cert_name)) {
            $updateFields[] = "cert_name = :cert_name";
            $params[':cert_name'] = $cert_name;
        }

        if (!empty($cert_tname)) {
            $updateFields[] = "cert_tname = :cert_tname";
            $params[':cert_tname'] = $cert_tname;
        }

        if (!empty($cert_image)) {
            $updateFields[] = "cert_image = :cert_image";
            $params[':cert_image'] = $cert_image;
        }

        if ($type == "multi") { // หลายรายการ

            if (isset($_POST["idcheckbox"])) {
                $list_arr = $_POST["idcheckbox"];
                $list = implode(",", $list_arr);
            } else {
                $_SESSION['error'] = "ไม่สามารถทำรายการได้ในขณะนี้";
                header("location: $page");
                exit;
            }

            $var = "IN ($list)";
            
        } else if ($user_id == $id || $userData['role']  == "admin") {
            $var = "= $id";

            if ($type == "image" && $userData['role']  == "admin") {

                $stmt = $pdo->prepare("SELECT cert_image FROM $table WHERE id = ?");
                $stmt->execute([$id]);
                $result = $stmt->fetch();

                if (!empty($result['cert_image'])) {
                    $filepath = '../' . $result['cert_image'];
                    if (file_exists($filepath)) {
                        unlink($filepath);
                    }
                }

                if (!file_exists('../assets/certificate/'. $id)) { // เช็คว่ามีโฟเดอร์หรือไม่
                    mkdir('../assets/certificate/'. $id, 0777, true);
                }

                $target_dir = "../assets/certificate/". $id;

                if ($certExt == "pdf") {
                    function convertPngToJpg($pngFile, $jpgFile) {
                        if (file_exists($pngFile)) {
                            $image = imagecreatefrompng($pngFile);
                            $bg = imagecreatetruecolor(imagesx($image), imagesy($image));
                            imagefill($bg, 0, 0, imagecolorallocate($bg, 255, 255, 255));
                            imagealphablending($bg, TRUE);
                            imagecopy($bg, $image, 0, 0, 0, 0, imagesx($image), imagesy($image));
                            imagedestroy($image);
                            imagejpeg($bg, $jpgFile, 90);
                            imagedestroy($bg);

                            unlink($pngFile);
                            
                            return true;
                        }
                        return false;
                    }

                    if(isset($_FILES["certImg"]) && !empty($_FILES["certImg"]["name"])) {
                        $imageTarget = $target_dir . basename($_FILES["certImg"]["name"]);
                        $imageExt = strtolower(pathinfo($imageTarget, PATHINFO_EXTENSION));
                        $imageUploadOk = 1;
                        $new_filename = "/certificate-no$id-$cert_num-thum.$imageExt";
                        $target_file = $target_dir . $new_filename;
                        $path = str_replace('../', '', $target_file);

                        if($imageExt == "jpg" || $imageExt == "jpeg" || $imageExt == "png") {
                            $check = getimagesize($_FILES["certImg"]["tmp_name"]);
                            if($check === false) {
                                $imageUploadOk = 0;
                            }
                        } else {
                            $imageUploadOk = 0;
                        }

                        if($imageUploadOk == 1) {
                            if(move_uploaded_file($_FILES["certImg"]["tmp_name"], $target_file)) {
                                if($imageExt == "png" || $imageExt == "jpeg") {
                                    $temp_png_file = $target_file;
                                    $target_file = $target_dir . "/certificate-no$id-$cert_num-thum.jpg";
                                    $path = str_replace('../', '', $target_file);
                                    convertPngToJpg($temp_png_file, $target_file);
                                }
                            } else {
                                $_SESSION['error'] = "มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง";
                            }
                        }
                    }

                    if(isset($_FILES["certPdf"]) && !empty($_FILES["certPdf"]["name"])) {
                        $pdfTarget = $target_dir . basename($_FILES["certPdf"]["name"]);
                        $certExt = strtolower(pathinfo($pdfTarget, PATHINFO_EXTENSION));
                        $pdfUploadOk = 1;
                        $new_pdfname = "/certificate-no$id-$cert_num.$certExt";
                        $target_pdf = $target_dir . $new_pdfname;
                        $path = str_replace('../', '', $target_pdf);

                        if($certExt == "pdf") {
                            $finfo = finfo_open(FILEINFO_MIME_TYPE);
                            $mime = finfo_file($finfo, $_FILES["certPdf"]["tmp_name"]);
                            finfo_close($finfo);
                            
                            if($mime != "application/pdf") {
                                $pdfUploadOk = 0;
                            }
                        } else {
                            $pdfUploadOk = 0;
                        }
                        
                        if($pdfUploadOk == 1) {
                            if(!move_uploaded_file($_FILES["certPdf"]["tmp_name"], $target_pdf)) {
                                $_SESSION['error'] = "มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง";
                            }
                        }
                    }
                } else {
                    $target_file = $target_dir . basename($_FILES["certImg"]["name"]);
                    $uploadOk = 1;
                    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
                    $new_filename = "/certificate-no$id-$cert_num.$imageFileType";
                    $target_file = $target_dir . $new_filename;
                    $path = str_replace('../', '', $target_file);
    
                    if(isset($_POST["uploadCert"])) {
                        $check = getimagesize($_FILES["certImg"]["tmp_name"]);
    
                        if($check !== false) {
                            $uploadOk = 1;
                        } else {
                            $uploadOk = 0;
                        }
                    }
    
                    if($imageFileType != "jpg" && $imageFileType != "jpeg" && $imageFileType != "png") {
                        $uploadOk = 0;
                    }
    
                    if ($uploadOk == 0 || !move_uploaded_file($_FILES["certImg"]["tmp_name"], $target_file)) {
                        $_SESSION['error'] = "มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง";
                    }
                }
            }
        }

        try {
            if ($action == "remImage") {

                if ($type == "multi") {
                    $var2 = " id,";
                }
            
                $sql = "SELECT" .$var2. " cert_image FROM $table WHERE id " . $var;
                $stmt = $pdo -> prepare($sql);
                $stmt -> execute();
            
                if ($type == "multi") {
                    $result = $stmt -> fetchAll();
                    foreach ($result as $img) {
                        if (!empty($img['cert_image'])) {
                            $filepath = '../' . $img['cert_image'];
                            if (file_exists($filepath)) {
                                unlink($filepath);
                            }

                            $path_parts = pathinfo($filepath);
                            if (strtolower($path_parts['extension']) == 'pdf') {
                                $thumbPath = $path_parts['dirname'] . '/' . str_replace('.' . $path_parts['extension'], '-thum.jpg', $path_parts['basename']);
                                if (file_exists($thumbPath)) {
                                    unlink($thumbPath);
                                }

                                $thumbPathPng = $path_parts['dirname'] . '/' . str_replace('.' . $path_parts['extension'], '-thum.png', $path_parts['basename']);
                                if (file_exists($thumbPathPng)) {
                                    unlink($thumbPathPng);
                                }
                                
                                $thumbPathJpeg = $path_parts['dirname'] . '/' . str_replace('.' . $path_parts['extension'], '-thum.jpeg', $path_parts['basename']);
                                if (file_exists($thumbPathJpeg)) {
                                    unlink($thumbPathJpeg);
                                }
                            }
                        }
                    }
                } else {
                    $result = $stmt -> fetch();
                    if (!empty($result['cert_image'])) {
                        $filepath = '../' . $result['cert_image'];
                        if (file_exists($filepath)) {
                            unlink($filepath);
                        }

                        $path_parts = pathinfo($filepath);
                        if (strtolower($path_parts['extension']) == 'pdf') {
                            $thumbPath = $path_parts['dirname'] . '/' . str_replace('.' . $path_parts['extension'], '-thum.jpg', $path_parts['basename']);
                            if (file_exists($thumbPath)) {
                                unlink($thumbPath);
                            }

                            $thumbPathPng = $path_parts['dirname'] . '/' . str_replace('.' . $path_parts['extension'], '-thum.png', $path_parts['basename']);
                            if (file_exists($thumbPathPng)) {
                                unlink($thumbPathPng);
                            }
                            
                            $thumbPathJpeg = $path_parts['dirname'] . '/' . str_replace('.' . $path_parts['extension'], '-thum.jpeg', $path_parts['basename']);
                            if (file_exists($thumbPathJpeg)) {
                                unlink($thumbPathJpeg);
                            }
                        }
                    }
                }
            }

            if ($type == "image") {
                $sql = "UPDATE $table SET cert_image = '".$path."' WHERE id " . $var;
            } else if ($action == "remImage") {
                $sql = "UPDATE $table SET cert_image = NULL WHERE id " . $var;
            } else if (!empty($updateFields)) {
                $sql = "UPDATE $table SET " . implode(", ", $updateFields) . " WHERE id " . $var;
            } else {
                $_SESSION['error'] = "ไม่สามารถทำรายการได้ในขณะนี้";
                header("location: $page");
                exit;
            }

            $stmt = $pdo -> prepare($sql);
            $stmt -> execute($params);

            if ($action == "certEdit") {
                $_SESSION['success'] = "แก้ไขรายการเกียรติบัตรที่เลือกทั้งหมด ".count($list_arr)." รายการแล้ว";
            } else if ($action == "remImage") {
                if ($type == "multi") {
                    $_SESSION['success'] = "ลบรูปภาพเกียรติบัตรที่เลือกทั้งหมด ".count($list_arr)." รายการแล้ว";
                } else {
                    $_SESSION['success'] = "ลบรูปภาพเกียรติบัตรรายการที่: <b>".$id."</b> สำเร็จ!";
                }
            } else {
                $_SESSION['success'] = "บันทึกข้อมูลเกียรติบัตรรายการที่: <b>".$id."</b> สำเร็จ!";
            }

            header("location: $page");
            exit;

        } catch (PDOException $e) {
            if ($action == "certEdit") {
                $_SESSION['error'] = "ไม่สามารถแก้ไขรายการเกียรติบัตรที่เลือกทั้งหมด ".count($list_arr)." รายการได้ในขณะนี้";
            } else if ($action == "remImage") {
                if ($type == "multi") {
                    $_SESSION['error'] = "ไม่สามารถลบรูปภาพเกียรติบัตรที่เลือกทั้งหมด ".count($list_arr)." รายการได้ในขณะนี้";
                } else {
                    $_SESSION['error'] = "ไม่สามารถลบรูปภาพเกียรติบัตรรายการที่: <b>".$id."</b> ได้ในขณะนี้";
                }
            } else {
                $_SESSION['error'] = "มีบางอย่างผิดพลาด กรุณาลองอีกครั้ง";
            }

            $_SESSION['log'] = $e;
            header("location: $page");
            exit;
        }

    } else {
        $_SESSION['error'] = "กรุณาลองอีกครั้ง";
        header("location: $page");
    }