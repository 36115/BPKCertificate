<?php
    // เริ่ม Session (ต้องมีทุกหน้า)
    session_start();
    require '../config.php';

    // เช็คว่าส่งมาจาก URL ไหน
    if (strpos($_SERVER['REQUEST_URI'], "user-info") !== false) {
        $pattern = '/id=(\d+)/';

        if (preg_match($pattern, $_SERVER['REQUEST_URI'], $matches)) {
            $id = $matches[1];
        }

        $page = "../user-info?id=$id";
    } else if (strpos($_SERVER['REQUEST_URI'], "dashboard") !== false) {
        $page = "../dashboard";
    } else if (strpos($_SERVER['REQUEST_URI'], "manual") !== false) {
        $page = "../manual";
    } else {
        $page = "../";
    }

    // ขอ UserID ผู้ใช้
    $user_id = $_SESSION['user_id'];
    $id = $_GET["id"];

    if ($user_id == $id) {
        $minLength = 6;
        $UserminLength = 3;
        $maxLength = 20;
        $passwordCheck = false;
        $sameUser = 1;

        try {
            $username = $_POST['username'];
            $realname = $_POST['fname']." ".$_POST['lname'];
            $email = strtolower($_POST['email']);
            $password = $_POST['password'];
            $edited = date("Y-m-d H:i:s");
            
            if (!empty($password)) {
                $passwordCheck = true;
            }

            if (empty($username)) {
                $_SESSION['error'] = "กรุณาใส่ชื่อผู้ใช้";
                $_SESSION['log'] = "กรุณาใส่ชื่อผู้ใช้ โดยชื่อผู้ใช้ควรมีความยาวไม่ต่ำกว่า 3 และไม่เกิน 20 ตัวอักษร และต้องเป็นอักขระภาษาอังกฤษเท่านั้น";
                header("location: $page");
            } else if (strlen($username) < $UserminLength || strlen($username) > $maxLength || preg_match('/[^\x00-\x7F]/', $username)) {
                $_SESSION['error'] = "กรุณาใส่ชื่อผู้ใช้ให้ถูกต้อง";
                $_SESSION['log'] = "ชื่อผู้ใช้ควรมีความยาวไม่ต่ำกว่า 3 และไม่เกิน 20 ตัวอักษร และต้องเป็นอักขระภาษาอังกฤษเท่านั้น";
                header("location: $page");
            } else if (!filter_var($email, FILTER_VALIDATE_EMAIL) || preg_match('/[^\x00-\x7F]/', $email)) {
                $_SESSION['error'] = "กรุณาใส่ Email ให้ถูกต้อง";
                $_SESSION['log'] = "ตรวจสอบว่ารูปแบบ Email ถูกต้องหรือไม่";
                header("location: $page");
            } else {
                if ($passwordCheck == true) {

                    if (strlen($password) < $minLength) {
                        $_SESSION['error'] = "กรุณาใส่รหัสผ่านให้ถูกต้อง";
                        $_SESSION['log'] = "รหัสผ่านควรมีความยาวไม่ต่ำกว่า 6 ตัวอักษร";
                        header("location: $page");
                        exit;
                    }

                    $hashPassword = password_hash($password, PASSWORD_DEFAULT);
                }

                $hashPassword = password_hash($password, PASSWORD_DEFAULT); 

                $checkUsername = $pdo -> prepare("SELECT COUNT(*) FROM users WHERE username = ?");
                $checkUsername -> execute([$username]);
                $usernameExists = $checkUsername -> fetchColumn();

                $checkEmail = $pdo -> prepare("SELECT COUNT(*) FROM users WHERE email = ?");
                $checkEmail -> execute([$email]);
                $userEmailExists = $checkEmail -> fetchColumn();

                // ขอ UserID ผู้ใช้
                $user_id = $_SESSION['user_id'];
                $stmt = $pdo -> prepare("SELECT * FROM users WHERE id = ?");
                $stmt -> execute([$user_id]);
                $userData = $stmt -> fetch();

                if ($username == $userData["username"] && $_SESSION['user_id'] == $userData["id"]) {
                    $sameUser = 1;
                }

                if ($usernameExists && $sameUser == 0) {
                    $_SESSION['error'] = "ชื่อผู้ใช้: <b>$username</b> ถูกใช้ไปแล้ว";
                    $_SESSION['log'] = "กรุณาใช้ Username ที่ไม่ซ้ำกัน";
                    header("location: $page");
                    exit;
                } else if ($userEmailExists && $sameUser == 0) {
                    $_SESSION['error'] = "Email: <b>$email</b> ถูกใช้ไปแล้ว";
                    $_SESSION['log'] = "กรุณาใช้ Email ที่ไม่ซ้ำกัน";
                    header("location: $page");
                    exit;
                }

                if ($sameUser = 1) {
                    if ($passwordCheck == true) {
                        $stmt = $pdo -> prepare("UPDATE users SET username = ?, realname = ?, email = ?, password = ?, edited_date = ? WHERE id = ".$id."");
                        $stmt->execute([$username, $realname, $email, $hashPassword, $edited]);
                    } else {
                        $stmt = $pdo -> prepare("UPDATE users SET username = ?, realname = ?, email = ?, edited_date = ? WHERE id = ".$id."");
                        $stmt->execute([$username, $realname, $email, $edited]);
                        
                        $_SESSION['success'] = "แก้ไขข้อมูลผู้ใช้สำเร็จ";
                        header("location: $page");
                    }
                }
            }
        } catch (PDOException $e) {
            $_SESSION['error'] = "ไม่สามารถแก้ไขข้อมูลผู้ใช้ได้ในขณะนี้";
            $_SESSION['log'] = $e;
            header("location: $page");
        }

    } else {
        $_SESSION['error'] = "กรุณาลองอีกครั้ง";
        header("location: $page");
    }
