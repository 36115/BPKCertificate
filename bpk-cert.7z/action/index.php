<?php
    // Redirect หากไม่พบหน้าเว็บ
    header("location: /bpk-cert");