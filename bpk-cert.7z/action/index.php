<?php
    // Redirect ไปหน้าเว็บหลัก
    require '../config.php';
    header("location: /$rootname");