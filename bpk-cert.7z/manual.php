<?php
    // ค่าสำหรับเข้าหน้าเว็บได้
    define('SECURE_ACCESS', true);

    // เริ่ม Session (ต้องมีทุกหน้า)
    session_start();
    require 'config.php';
    require_once 'action/session.php';
    
    include_once 'component/nav.php';

    require_once 'assets/ajax/index.php';

    // ดึงข้อมูลจากตาราง cert_list แต่ละ user มาแสดง
    if ($userData['role'] == "admin") {
        $userAdmin = $pdo -> prepare("SELECT * FROM users");
        $userAdmin -> execute();
        $res = $pdo -> prepare("SELECT * FROM cert_list");
    } else {
        $res = $pdo -> prepare("SELECT * FROM cert_list WHERE user_id = :id");
        $res -> bindParam(':id', $user_id, PDO::PARAM_INT);
    }
    $res -> execute();

    // ดูว่า cert_list มีข้อมูลหรือไม่ $userAdmin["user_id"]
    $count = $res -> rowCount();
    $i = 1;
?>

<!DOCTYPE html>
<html lang="en" data-bs-theme="<?php echo $mode;?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>คู่มือการใช้งาน | <?php echo $webName;?></title>
</head>
<body>
    <section style="padding: 8em 0;">
        <div class="container">
            <div class="row justify-content-center">
            <?php include_once 'component/alert.php';?>
            <p class="text-body-emphasis user-select-none fw-bolder p-3"><i class="fas fa-house-chimney"></i> <a href="/<?php echo $rootname; ?>" class="text-body-emphasis">หน้าหลัก</a> / <a href="manual" class="text-body-emphasis">คู่มือการใช้งาน</a> /</p>
                <div class="card bg-body p-7 mb-4 rounded-4">
                    <h1 class="pt-4 my-5 text-body-emphasis text-center">คู่มือการใช้งาน</h1>
                    <h4 class="pt-3 pb-3 mb-6 text-body-emphasis border-bottom"><span class="fa fa-award"></span> เกียรติบัตร</h4>
                    <h3 id="addCert" class="pt-3 pb-3 mb-6 text-body-emphasis">1. เพิ่มรายการขอเกียรติบัตร</h3>
                    <ul>
                        <li>กรอกข้อมูลในแต่ละช่องให้เรียบร้อย</li>
                        <div class="p-3 d-flex justify-content-center">
                            <img class="w-100 h-100" src="assets/manual/addCert/1.png">
                        </div>

                        <li>คลิกที่ <b>"ยืนยันข้อมูล"</b> เพื่อทำการขอเกียรติบัตร</li>
                        <div class="p-3 d-flex justify-content-center">
                            <img class="w-100 h-100" src="assets/manual/addCert/2.png">
                        </div>

                        <li>จะเห็นว่ามีรายการเกียรติบัตรเพิ่มในรายการขอ</li>
                        <div class="p-3 d-flex justify-content-center">
                            <img class="w-100 h-100" src="assets/manual/addCert/3.png">
                        </div>
                    </ul>

                    <?php if ($userData['role'] == "admin") {?>
                        <h3 id="certUrl" class="pt-3 pb-3 mb-6 text-body-emphasis">2. เพิ่มและลบลิงก์ดาวน์โหลดเกียรติบัตรในรายการ</h3>
                        <ul>
                            <li>คลิกที่ <b>"ตัวเลือก"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/certUrl/1.png">
                            </div>

                            <li>คลิกที่ <b>"เลือกรายการ"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/certUrl/2.png">
                            </div>

                            <li>เลือกรายการที่ต้องการใส่ลิงก์ หรือเลือกทั้งหมดได้</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/certUrl/3.png">
                            </div>

                            <h5 class="pt-3 pb-3 mb-6 text-body-emphasis border-bottom">เพิ่มลิงก์</h5>

                            <li>คลิกที่ <b>"ตัวเลือก" > "เพิ่มลิงก์"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/certUrl/4.png">
                            </div>

                            <li>ใส่ลิงก์ที่ต้องการส่งให้ผู้ขอเกียรติบัตร จากนั้นคลิกที่ <b>"ยืนยัน"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-50 h-50" src="assets/manual/certUrl/5.png">
                            </div>

                            <li>จะเห็นว่าได้เพิ่มลิงก์ในรายการของผู้ขอเกียรติบัตรแล้ว</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/certUrl/6.png">
                            </div>

                            <h5 class="pt-3 pb-3 mb-6 text-body-emphasis border-bottom">ลบลิงก์</h5>

                            <li>คลิกที่ <b>"ตัวเลือก" > "ลบลิงก์"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-50 h-50" src="assets/manual/certUrl/7.png">
                            </div>

                            <li>คลิกที่ <b>"OK"</b> เพื่อยืนยัน</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-50 h-50" src="assets/manual/certUrl/8.png">
                            </div>

                            <li>จะเห็นว่าได้ลบลิงก์ในรายการของผู้ขอเกียรติบัตรแล้ว</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/certUrl/9.png">
                            </div>
                        </ul>
                    <?php } ?>
                </div>

                <?php if ($userData['role'] == "admin") {?>
                    <div class="card bg-body p-7 mb-4 rounded-4">
                        <h4 class="pt-3 pb-3 mb-6 text-body-emphasis border-bottom"><span class="fa fa-users"></span> ผู้ใช้งาน</h4>

                        <h3 id="userCfg" class="pt-3 mb-4 text-body-emphasis">1. เพิ่ม ลบ และแก้ไขผู้ใช้งานในระบบ</h3>
                        <ul>
                            <h5 class="pt-3 pb-3 mb-6 text-body-emphasis border-bottom">เข้าหน้า Dashboard</h5>

                            <li>คลิกที่เมนูข้างบนเว็บ</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userCfg/1.png">
                            </div>

                            <li>คลิกที่ <b>"เมนู Admin"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-25 h-25" src="assets/manual/userCfg/2.png">
                            </div>

                            <li>คลิกที่ <b>"เข้าสู่หน้า Admin Dashboard"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-50 h-50" src="assets/manual/userCfg/3.png">
                            </div>

                            <li>จะเห็นว่าได้เข้าสู่หน้า Dashboard แล้ว</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userCfg/4.png">
                            </div>

                            <h5 class="pt-3 pb-3 mb-6 text-body-emphasis border-bottom">เพิ่มผู้ใช้</h5>

                            <li>คลิกที่ <b>"เพิ่มผู้ใช้"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userCfg/5.png">
                            </div>

                            <li>กรอกข้อมูลในแต่ละช่องให้เรียบร้อยแล้วคลิกที่ <b>"ยืนยันข้อมูล"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-50 h-50" src="assets/manual/userCfg/6.png">
                            </div>

                            <li>จะเห็นว่าได้ทำการเพิ่มผู้ใช้แล้ว</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userCfg/7.png">
                            </div>

                            <h5 class="pt-3 pb-3 mb-6 text-body-emphasis border-bottom">ลบผู้ใช้ (รายการเดียว)</h5>

                            <li>คลิกที่ไอคอน 3</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userCfg/8.png">
                            </div>

                            <li>คลิกที่ <b>"OK"</b> เพื่อยืนยัน</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-50 h-50" src="assets/manual/userCfg/9.png">
                            </div>

                            <li>จะเห็นว่าได้ทำการลบผู้ใช้แล้ว</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userCfg/10.png">
                            </div>

                            <h5 class="pt-3 pb-3 mb-6 text-body-emphasis border-bottom">ลบผู้ใช้ (หลายรายการ)</h5>

                            <li>คลิกที่ <b>"ตัวเลือก"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userCfg/11.png">
                            </div>

                            <li>คลิกที่ <b>"เลือกรายการ"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userCfg/12.png">
                            </div>

                            <li>เลือกรายการผู้ใช้ที่ต้องการลบ หรือเลือกทั้งหมดได้</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userCfg/13.png">
                            </div>

                            <li>คลิกที่ <b>"ลบผู้ใช้"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-50 h-50" src="assets/manual/userCfg/14.png">
                            </div>

                            <li>คลิกที่ <b>"OK"</b> เพื่อยืนยัน</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-50 h-50" src="assets/manual/userCfg/15.png">
                            </div>

                            <li>จะเห็นว่าได้ทำการลบผู้ใช้ที่เลือกแล้ว</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userCfg/16.png">
                            </div>

                            <h5 class="pt-3 pb-3 mb-6 text-body-emphasis border-bottom">แก้ไขข้อมูลผู้ใช้</h5>

                            <li>คลิกที่ไอคอนแรก</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userCfg/17.png">
                            </div>

                            <li>แก้ไขข้อมูลในแต่ละช่องให้เรียบร้อยแล้วคลิกที่ <b>"บันทึก"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-50 h-50" src="assets/manual/userCfg/18.png">
                            </div>

                            <li>จะเห็นว่าได้แก้ไขข้อมูลผู้ใช้แล้ว</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userCfg/19.png">
                            </div>

                            <h5 class="pt-3 pb-3 mb-6 text-body-emphasis border-bottom">แสดงข้อมูลผู้ใช้</h5>

                            <li>คลิกที่ไอคอน 2</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userCfg/20.png">
                            </div>

                            <li>จะเห็นว่าได้ทำการแสดงผู้ใช้ที่เลือกแล้ว</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userCfg/21.png">
                            </div>
                            
                        </ul>

                        <ul>
                            <h3 id="userReq" class="pt-3 mb-4 text-body-emphasis">2. แก้ไขข้อมูลตามรายการคำขอผู้ใช้</h3>

                            <li>เลื่อนลงมาข้างล่างสุด จากนั้นคลิกที่ <b>"แก้ไข"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userReq/1.png">
                            </div>

                            <li>สามารถดูรายละเอียดหรือลบคำขอได้ จากนั้นคลิกที่ <b>"แก้ไขข้อมูล"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-50 h-50" src="assets/manual/userReq/2.png">
                            </div>

                            <li>กรอกข้อมูลในแต่ละช่องให้เรียบร้อยแล้วคลิกที่ <b>"บันทึก"</b></li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-50 h-50" src="assets/manual/userReq/3.png">
                            </div>

                            <li>จะเห็นว่าได้ทำการแก้ไขข้อมูลผู้ใช้แล้ว</li>
                            <div class="p-3 d-flex justify-content-center">
                                <img class="w-100 h-100" src="assets/manual/userReq/4.png">
                            </div>

                        </ul>
                    </div>
                <?php } ?>

            </div>
        </div>
    </section>
    <?php include_once 'component/footer.php';?>
</body>

</html>